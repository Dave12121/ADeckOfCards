package aDeckOfCards;

public class OneDeckUnshuffled 
{
	public OneDeckUnshuffled()
	{
		
	}
	
	public String[] makeDeckArray()
	{
		//array of 52 strings
	}
	
	public String[] initializeDeck(String[]theDeck)
	{
		//assign numeric(toString()) value to each card 
		//card numbers are 1 to 52
	}
	
	public String[] addSuiteToDeckString(String[] theDeck)
	{
		//append suite to each card number
		//1-13 clubs
		//14-26 diamonds
		//27-39 hearts
		//40-52 spades
	}
	
	public String[] addCardNumberToDeckString(String[] theDeck)
	{
		//append card number to each card that will end up with a number 
		// card[0] will contain "1"
		// card[2] will contain "2 2"
		// card[10] will contain "11"
		// card[14] will contain "14 2"
	}
	
	public String[] addFaceNameToDeckString(String[] theDeck)
	{
		//append face name to each card that will end up with a face name
	}
	
	public String[] addAceToDeckString(String[] theDeck)
	{
		//append 'ace' to each card that will end up as an ace
	}
	
	public String[] returnTheDeck(String[] theDeck)
	{
		
	}
}
